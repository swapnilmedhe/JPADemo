package com.cybage.main;

import java.util.Arrays;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.domain.PageRequest;

import com.cybage.model.Product;
import com.cybage.repository.ProductRepository;
import com.cybage.service.ProductService;

/** 
 * Simple tester for Spring-Data-JPA.
 **/
public class SpringDataJPAMain {
	
	/*static private PageRequest gotoPage(int page)
    {
        PageRequest request = new PageRequest(page,1);
        return request;
    }*/
	
	public static void main(String[] args) {

		//Create Spring application context
		ApplicationContext ctx = new ClassPathXmlApplicationContext("classpath:/spring-config.xml");
		
		//Get service from context.
		ProductService productService = ctx.getBean(ProductService.class);
		

		//Add some items
		productService.add(new Product(1, "MotoG5"));
		productService.add(new Product(2, "MotoEPlus"));
		productService.addAll(Arrays.asList(
				new Product(3, "OPPOF7"), 
				new Product(4, "OnePlus"), 
				new Product(5, "iPhone"),
				new Product(6, "Samsung")
				));
		
		//System.out.println("findByName is 'iPhone': " + productService.findByNameIs("iPhone"));
	//	System.out.println("findByNameContainingIgnoreCase 'on': " + productService.findByNameContainingIgnoreCase("on"));
		//System.out.println("findByNameIs 'on': " + productService.findByNameIs("MotoG5"));
		//List<Product> lp= productService.find("MotoG5",1);
	//	System.out.println("Find by name and id: "+lp );
		
		
		//Test entity listing
		//System.out.println("findAll=" + productService.findAll());

		//Test specified find methods 
		
		//Test Pageable
		//System.out.println("Only 2 Products at a time: "+productService.getProductList(1));
		Iterable<Product> pList = productService.getProductList(1);
	        for(Product p : pList)
	        System.out.println("Product " + p);
		
				
		((AbstractApplicationContext) ctx).close();
	}
}

