package com.cybage.service;

import java.util.Collection;
import java.util.List;

import org.hibernate.annotations.Sort;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.model.Product;
import com.cybage.repository.ProductRepository;

/** 
 * Service layer.
 * Specify transactional behavior and mainly
 * delegate calls to Repository.
 */
@Service
public class ProductService {

	  private static final int PAGE_SIZE = 3;
	  
	@Autowired
	private ProductRepository productRepository;

	@Transactional
	public void add(Product product) {
				productRepository.save(product);
		
	}
	
	
	/*@Transactional
	public List<Product> find(String name,int id) {
		return productRepository.findByNameAndId(name, id);
		
	}
	*/
	@Transactional(readOnly=true)
	public List<Product> findAll() {
		return productRepository.findAll();
	}
	
	@Transactional(readOnly=true)
	public Page<Product> getProductList(Integer pageNumber) {
		PageRequest request=new PageRequest(pageNumber, PAGE_SIZE,org.springframework.data.domain.Sort.Direction.DESC,"name");
	        return productRepository.findAll(request);

	}
	

	@Transactional
	public void addAll(Collection<Product> products) {
		for (Product product : products) {
			productRepository.save(product);
			
		}
	}

	/*@Transactional(readOnly=true)
	public List<Product> findByNameIs(String name) {
		return productRepository.findByNameIs(name);
	}
	
	@Transactional(readOnly=true)
	public List<Product> findByNameContainingIgnoreCase(String searchString) {
		return productRepository.findByNameContainingIgnoreCase(searchString);
	}*/
}
